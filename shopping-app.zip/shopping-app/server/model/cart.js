const db = require("../util/database");

// we are not creating a new cart! Just parse in specific product into cart
class Cart {
  //we will add the existing product into cart instead
  static addCart(id, quantity = 1, sessionUserID) {
    return db.query(
      `INSERT INTO cart(product_id, quantity, user_id, delivery_options)
                VALUES($1, $2, $3, 1)
                ON CONFLICT(product_id, user_id)
                DO UPDATE
                SET quantity = cart.quantity + $2`,
      [id, quantity, sessionUserID],
    );
  }

  static async fetchAllCart(sessionUserID) {
    return db.query(
      `
                SELECT
                cart.id,
                cart.quantity,
                cart.product_id,
                cart.delivery_options,
                products.title,
                products.price,
                products.description,
                products.imageurl,
                (cart.quantity * products.price) AS item_total,
                delivery_options.price_dollars,
                delivery_options.delivery_days
                FROM cart
                INNER JOIN products
                ON cart.product_id = products.id
                INNER JOIN delivery_options
                ON cart.delivery_options = delivery_options.id
                WHERE cart.user_id = $1`,
      [sessionUserID],
    );
  }

  //delete selected cart
  static deleteCart(id, userID) {
    return db.query(
      `DELETE FROM cart
                WHERE 
                id = $1 AND user_id = $2`,
      [id, userID],
    );
  }

  //update cart delivery options
  static updateCartDeliveryOptions(deliveryOptions, cartID, sessionUserID) {
    return db.query(
      `
        UPDATE cart
        SET delivery_options = $1
        WHERE id = $2 AND user_id = $3`,
      [deliveryOptions, cartID, sessionUserID],
    );
  }

  static async deleteOrderedCart(sessionUserID) {
    return db.query(`DELETE FROM cart WHERE user_id = $1`, [sessionUserID]);
  }
}

module.exports = Cart;
